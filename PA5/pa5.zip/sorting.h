#ifndef __SORTING_H__
#define __SORTING_H__

void Quick_Sort(long *Array, int Size);
void Merge_Sort(long *Array, int Size);

#endif